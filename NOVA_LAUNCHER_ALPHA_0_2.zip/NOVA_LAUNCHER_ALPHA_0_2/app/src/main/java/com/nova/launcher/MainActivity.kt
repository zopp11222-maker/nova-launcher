package com.nova.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B1015)
private val Panel = Color(0xFF151E26)
private val Green = Color(0xFF49D49A)
private val Muted = Color(0xFF9AAAB5)
private val Warn = Color(0xFFFFC66D)
private val Bad = Color(0xFFFF7B7B)
private val Deep = Color(0xFF203C34)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

@Composable
fun NovaApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("Home") }
    var profiles by remember { mutableStateOf(ModTools.loadProfiles(ctx)) }
    var activeName by remember { mutableStateOf(profiles.first().name) }
    val profile = profiles.firstOrNull { it.name == activeName } ?: profiles.first()
    var mods by remember { mutableStateOf(listOf<ModInfo>()) }
    var issues by remember { mutableStateOf<List<Issue>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("Welcome to NOVA Launcher 0.2") }
    var confirmFix by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }

    suspend fun refresh() {
        mods = withContext(Dispatchers.IO) { ModTools.scanAll(ctx, profile) }
        issues = null
    }
    LaunchedEffect(activeName) { refresh() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true
            val n = withContext(Dispatchers.IO) { uris.count { ModTools.importUri(ctx, it, profile) } }
            refresh()
            notice = "Imported $n of ${uris.size} file(s). Tap Check to scan."
            busy = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White, onPrimary = Color(0xFF06231A))) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                listOf("Home", "Mods", "Profiles", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = page == item, onClick = { page = item },
                        icon = {
                            Icon(when (item) {
                                "Home" -> Icons.Default.Home
                                "Mods" -> Icons.Default.Extension
                                "Profiles" -> Icons.Default.Folder
                                else -> Icons.Default.Settings
                            }, item)
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green,
                            indicatorColor = Deep, unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("NOVA", color = Green, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("MINECRAFT JAVA LAUNCHER", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
                    }
                    Pill("0.2 ALPHA")
                }
                if (busy) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green) }
                Spacer(Modifier.height(16.dp))
                when (page) {
                    "Home" -> HomePage(profile, mods, issues, notice)
                    "Mods" -> ModsPage(mods, issues, busy,
                        onImport = { picker.launch(arrayOf("*/*")) },
                        onCheck = { issues = ModTools.analyze(mods, profile); notice = "Scan finished." },
                        onFix = { confirmFix = true },
                        onToggle = { m -> scope.launch { withContext(Dispatchers.IO) { ModTools.toggle(m) }; refresh() } },
                        onRemove = { m -> scope.launch { withContext(Dispatchers.IO) { m.file.delete() }; refresh() } })
                    "Profiles" -> ProfilesPage(profiles, activeName, { activeName = it.name }, { showCreate = true }) { t ->
                        if (profiles.size > 1) {
                            profiles = profiles.filterNot { it == t }
                            ModTools.saveProfiles(ctx, profiles)
                            if (activeName == t.name) activeName = profiles.first().name
                        }
                    }
                    else -> SettingsPage(profile)
                }
            }
        }

        if (confirmFix) {
            val todo = issues.orEmpty().filter { it.kind == "conflict" || it.kind == "missing" }
            AlertDialog(
                onDismissRequest = { confirmFix = false },
                title = { Text("Apply these changes?") },
                text = {
                    Column {
                        todo.take(8).forEach {
                            Text((if (it.kind == "missing") "＋ Download: " else "－ Disable: ") + it.text, fontSize = 12.sp, color = Muted)
                        }
                        if (todo.size > 8) Text("…and ${todo.size - 8} more", fontSize = 12.sp, color = Muted)
                        Spacer(Modifier.height(8.dp))
                        Text("Nothing is deleted. Conflicting files are only renamed to .disabled.", fontSize = 11.sp, color = Green)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        confirmFix = false
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { ModTools.applyFixes(ctx, profile, todo) }
                            refresh(); notice = r.ifEmpty { "Nothing to change." }; busy = false
                        }
                    }) { Text("Apply") }
                },
                dismissButton = { TextButton(onClick = { confirmFix = false }) { Text("Cancel") } },
                containerColor = Panel, titleContentColor = Color.White, textContentColor = Muted
            )
        }

        if (showCreate) CreateProfileDialog(
            onDismiss = { showCreate = false },
            onCreate = { p ->
                if (p.name.isNotEmpty() && profiles.none { it.name.equals(p.name, true) }) {
                    profiles = profiles + p
                    ModTools.saveProfiles(ctx, profiles)
                    activeName = p.name
                }
                showCreate = false
            })
    }
}

@Composable
fun CreateProfileDialog(onDismiss: () -> Unit, onCreate: (Profile) -> Unit) {
    var name by remember { mutableStateOf("") }
    var mc by remember { mutableStateOf("1.20.1") }
    var loader by remember { mutableStateOf("fabric") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Profile") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Profile name") }, singleLine = true)
                OutlinedTextField(mc, { mc = it }, label = { Text("Minecraft version") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("fabric", "quilt", "forge", "neoforge").forEach {
                        FilterChip(selected = loader == it, onClick = { loader = it }, label = { Text(it, fontSize = 11.sp) })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(Profile(name.trim(), loader, mc.trim())) }) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = Panel, titleContentColor = Color.White, textContentColor = Muted
    )
}

@Composable
fun Pill(text: String) {
    Surface(color = Deep, shape = RoundedCornerShape(50)) {
        Text(text, color = Green, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
    }
}

@Composable
fun HomePage(p: Profile, mods: List<ModInfo>, issues: List<Issue>?, notice: String) {
    Text("Your game, your setup.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("A clean control center for Minecraft Java on Android.", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(16.dp))
    Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("ACTIVE PROFILE", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(p.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Minecraft ${p.mc} • ${p.loader}", color = Green, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(disabledContainerColor = Color(0xFF26352F))) {
                Text("PLAY  •  GAME ENGINE COMES IN ALPHA 0.4", color = Muted, fontSize = 12.sp)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("MODS", mods.size.toString(), Modifier.weight(1f))
        StatCard("ISSUES", issues?.count { it.kind != "warn" }?.toString() ?: "—", Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Text(notice, color = Muted, modifier = Modifier.padding(14.dp), fontSize = 12.sp)
    }
}

@Composable
fun ColumnScope.ModsPage(
    mods: List<ModInfo>, issues: List<Issue>?, busy: Boolean,
    onImport: () -> Unit, onCheck: () -> Unit, onFix: () -> Unit,
    onToggle: (ModInfo) -> Unit, onRemove: (ModInfo) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Mod Manager", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Scan, fix and organize .jar mods.", color = Muted, fontSize = 12.sp)
        }
        Button(onClick = onImport, enabled = !busy) { Icon(Icons.Default.Add, null); Text(" Import") }
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onCheck, enabled = !busy && mods.isNotEmpty(), modifier = Modifier.weight(1f)) {
            Icon(Icons.Default.Search, null); Text(" Check")
        }
        val fixable = issues.orEmpty().any { it.kind != "warn" }
        Button(onClick = onFix, enabled = !busy && fixable, modifier = Modifier.weight(1f)) {
            Icon(Icons.Default.AutoFixHigh, null); Text(" Auto-fix")
        }
    }
    Spacer(Modifier.height(10.dp))
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (issues != null) item {
            Surface(color = if (issues.isEmpty()) Deep else Color(0xFF352B19), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    if (issues.isEmpty()) Text("No problems found ✔", color = Green, fontSize = 12.sp)
                    issues.forEach {
                        Text("• " + it.text, fontSize = 11.sp,
                            color = when (it.kind) { "conflict" -> Bad; "missing" -> Warn; else -> Muted })
                    }
                }
            }
        }
        if (mods.isEmpty()) item { EmptyState("No mods yet", "Tap Import and pick .jar files.") }
        items(mods, key = { it.file.absolutePath }) { m ->
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Extension, null, tint = if (m.enabled) Green else Muted)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                        Text("${m.loader} • ${m.version} • ${m.id}", color = Muted, fontSize = 10.sp, maxLines = 1)
                    }
                    Switch(checked = m.enabled, onCheckedChange = { onToggle(m) })
                    IconButton(onClick = { onRemove(m) }) { Icon(Icons.Default.DeleteOutline, null, tint = Muted) }
                }
            }
        }
    }
}

@Composable
fun ProfilesPage(profiles: List<Profile>, active: String, onSelect: (Profile) -> Unit, onCreate: () -> Unit, onDelete: (Profile) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Profiles", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Each profile has its own mods folder.", color = Muted, fontSize = 12.sp)
        }
        Button(onClick = onCreate) { Icon(Icons.Default.Add, null); Text(" New") }
    }
    Spacer(Modifier.height(14.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(profiles, key = { it.name }) { p ->
            Surface(color = if (p.name == active) Deep else Panel, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().clickable { onSelect(p) }) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Folder, null, tint = Green)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${p.loader} • Minecraft ${p.mc}", color = Muted, fontSize = 11.sp)
                    }
                    if (profiles.size > 1) IconButton(onClick = { onDelete(p) }) { Icon(Icons.Default.DeleteOutline, null, tint = Muted) }
                }
            }
        }
    }
}

@Composable
fun SettingsPage(p: Profile) {
    Text("Settings", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    SettingRow("Active profile", "${p.name} • ${p.loader} ${p.mc}")
    SettingRow("Mod source", "Modrinth (downloads are checksum-verified)")
    SettingRow("Automatic changes", "Always ask the player first")
    SettingRow("Conflict handling", "Rename to .disabled, never delete")
    SettingRow("Game engine", "Not connected (planned Alpha 0.4)")
}

@Composable
fun SettingRow(title: String, value: String) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 0.5.sp)
            Text(value, color = Green, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun EmptyState(title: String, detail: String) {
    Box(Modifier.fillMaxWidth().padding(top = 35.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Inventory2, null, tint = Muted, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}
