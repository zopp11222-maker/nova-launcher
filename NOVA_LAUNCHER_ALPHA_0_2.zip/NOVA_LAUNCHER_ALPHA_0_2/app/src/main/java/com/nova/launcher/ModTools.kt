package com.nova.launcher

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.zip.ZipFile

data class Profile(val name: String, val loader: String = "fabric", val mc: String = "1.20.1")
data class ModInfo(
    val file: File, val id: String, val name: String, val version: String, val loader: String,
    val enabled: Boolean, val requires: List<String>, val breaks: List<String>, val provides: List<String>
)
data class Issue(val kind: String, val text: String, val modId: String, val file: File? = null)

object ModTools {
    private val builtin = setOf("minecraft", "java", "fabricloader", "fabric-loader", "forge", "neoforge",
        "quilt_loader", "quilt-loader", "fml", "javafml", "lowcodefml", "mixin")

    // ---------- storage ----------
    private fun safe(s: String) = s.replace(Regex("[^\\p{L}\\p{N} _-]"), "_")
    fun modsDir(ctx: Context, p: Profile) = File(ctx.filesDir, "profiles/${safe(p.name)}/mods").apply { mkdirs() }

    fun loadProfiles(ctx: Context): List<Profile> = try {
        val a = JSONArray(File(ctx.filesDir, "profiles.json").readText())
        List(a.length()) { val o = a.getJSONObject(it); Profile(o.getString("name"), o.optString("loader", "fabric"), o.optString("mc", "1.20.1")) }
            .ifEmpty { listOf(Profile("Default")) }
    } catch (e: Exception) { listOf(Profile("Default")) }

    fun saveProfiles(ctx: Context, list: List<Profile>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("name", it.name).put("loader", it.loader).put("mc", it.mc)) }
        File(ctx.filesDir, "profiles.json").writeText(a.toString())
    }

    fun importUri(ctx: Context, uri: Uri, p: Profile): Boolean = try {
        var name = "mod.jar"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0)
        }
        name = name.replace(Regex("[\\\\/]"), "_")
        if (!name.endsWith(".jar", true)) false else {
            ctx.contentResolver.openInputStream(uri)!!.use { i ->
                File(modsDir(ctx, p), name).outputStream().use { o -> i.copyTo(o) }
            }
            true
        }
    } catch (e: Exception) { false }

    fun toggle(m: ModInfo) {
        val n = if (m.enabled) m.file.name + ".disabled" else m.file.name.removeSuffix(".disabled")
        m.file.renameTo(File(m.file.parentFile, n))
    }

    fun scanAll(ctx: Context, p: Profile): List<ModInfo> =
        modsDir(ctx, p).listFiles { f -> f.name.endsWith(".jar") || f.name.endsWith(".jar.disabled") }
            .orEmpty().sortedBy { it.name.lowercase() }.map { scan(it) }

    // ---------- metadata ----------
    private fun scan(f: File): ModInfo {
        val enabled = !f.name.endsWith(".disabled")
        val fb = f.name.removeSuffix(".disabled").removeSuffix(".jar")
        try {
            ZipFile(f).use { z ->
                fun text(n: String) = z.getEntry(n)?.let { z.getInputStream(it).bufferedReader().readText() }
                text("fabric.mod.json")?.let { t ->
                    val j = JSONObject(t)
                    val prov = j.optJSONArray("provides")?.let { a -> List(a.length()) { a.optString(it) } } ?: emptyList()
                    return ModInfo(f, j.optString("id", fb), j.optString("name", fb), j.optString("version", "?"), "fabric", enabled,
                        (j.optJSONObject("depends")?.keys()?.asSequence()?.toList() ?: emptyList()).filter { it !in builtin },
                        j.optJSONObject("breaks")?.keys()?.asSequence()?.toList() ?: emptyList(), prov)
                }
                text("quilt.mod.json")?.let { t ->
                    val q = JSONObject(t).getJSONObject("quilt_loader")
                    val deps = mutableListOf<String>()
                    q.optJSONArray("depends")?.let { a ->
                        for (i in 0 until a.length()) {
                            val o = a.get(i)
                            val d = if (o is JSONObject) o.optString("id") else o.toString()
                            val opt = o is JSONObject && o.optBoolean("optional")
                            if (d.isNotEmpty() && !opt && d !in builtin) deps += d
                        }
                    }
                    return ModInfo(f, q.optString("id", fb), q.optJSONObject("metadata")?.optString("name", fb) ?: fb,
                        q.optString("version", "?"), "quilt", enabled, deps, emptyList(), emptyList())
                }
                for ((path, loader) in listOf("META-INF/neoforge.mods.toml" to "neoforge", "META-INF/mods.toml" to "forge")) {
                    text(path)?.let { return parseToml(it, f, enabled, loader, fb) }
                }
            }
        } catch (e: Exception) { }
        return ModInfo(f, fb, fb, "?", "unknown", enabled, emptyList(), emptyList(), emptyList())
    }

    private fun parseToml(t: String, f: File, enabled: Boolean, loader: String, fb: String): ModInfo {
        var id = fb; var name = fb; var ver = "?"; var section = ""
        var dep = ""; var mandatory = false
        val reqs = mutableListOf<String>()
        val rx = Regex("=\\s*\"([^\"]*)\"")
        fun flush() { if (section.startsWith("dependencies") && dep.isNotEmpty() && mandatory && dep !in builtin) reqs += dep }
        for (raw in t.lines()) {
            val l = raw.trim()
            if (l.startsWith("[[")) { flush(); section = l.trim('[', ']'); dep = ""; mandatory = false; continue }
            val v = rx.find(l)?.groupValues?.get(1)
            val inDep = section.startsWith("dependencies")
            when {
                l.startsWith("modId") -> if (inDep) dep = v ?: "" else if (section == "mods" && id == fb) id = v ?: fb
                l.startsWith("displayName") && section == "mods" && name == fb -> name = v ?: fb
                l.startsWith("version") && section == "mods" && ver == "?" -> ver = v ?: "?"
                l.startsWith("mandatory") -> mandatory = l.contains("true")
                l.startsWith("type") && inDep -> mandatory = v == "required"
            }
        }
        flush()
        return ModInfo(f, id, name, ver, loader, enabled, reqs, emptyList(), emptyList())
    }

    // ---------- conflict / dependency analysis ----------
    private fun loaderOk(mod: String, prof: String) = mod == "unknown" || mod == prof || (prof == "quilt" && mod == "fabric")

    fun analyze(mods: List<ModInfo>, p: Profile): List<Issue> {
        val out = mutableListOf<Issue>()
        val active = mods.filter { it.enabled }
        active.filter { it.loader == "unknown" }.forEach { out += Issue("warn", "${it.file.name}: no mod metadata found, cannot check it", it.id) }
        active.filter { !loaderOk(it.loader, p.loader) }.forEach {
            out += Issue("conflict", "${it.name} is a ${it.loader} mod, but this profile uses ${p.loader}", it.id, it.file)
        }
        val ok = active.filter { loaderOk(it.loader, p.loader) && it.loader != "unknown" }
        ok.groupBy { it.id }.filter { it.value.size > 1 }.forEach { (id, l) ->
            l.drop(1).forEach { out += Issue("conflict", "Duplicate mod '$id': ${it.file.name}", id, it.file) }
        }
        val ids = ok.flatMap { listOf(it.id) + it.provides }.toSet()
        for (m in ok) for (b in m.breaks) if (b in ids && b != m.id) {
            ok.firstOrNull { it.id == b }?.let { out += Issue("conflict", "${m.name} declares it breaks with ${it.name}", b, it.file) }
        }
        val missing = linkedSetOf<String>()
        for (m in ok) for (r in m.requires) {
            val k = if (r == "fabric" || r.matches(Regex("fabric-.*-v\\d+"))) "fabric-api" else r
            if (k !in ids && !(k == "fabric-api" && "fabric" in ids)) missing += k
        }
        missing.forEach { out += Issue("missing", "Missing required mod: $it", it) }
        return out
    }

    fun applyFixes(ctx: Context, p: Profile, issues: List<Issue>): String {
        var disabled = 0
        val log = mutableListOf<String>()
        for (i in issues) when {
            i.kind == "conflict" && i.file != null && i.file.exists() -> {
                if (i.file.renameTo(File(i.file.parentFile, i.file.name + ".disabled"))) disabled++
            }
            i.kind == "missing" -> log += download(i.modId.let { if (it == "fabric") "fabric-api" else it }, p, modsDir(ctx, p))
        }
        return (listOf(if (disabled > 0) "Disabled $disabled conflicting file(s) (not deleted)" else "") + log).filter { it.isNotEmpty() }.joinToString(" • ")
    }

    // ---------- Modrinth ----------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "NOVA-Launcher/0.2 (android)")
        c.connectTimeout = 15000; c.readTimeout = 20000
        try {
            if (c.responseCode != 200) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally { c.disconnect() }
    }

    private fun sha1(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { i -> val b = ByteArray(8192); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun download(id: String, p: Profile, dir: File): String {
        return try {
            val ld = if (p.loader == "quilt") "[\"quilt\",\"fabric\"]" else "[\"${p.loader}\"]"
            val arr = JSONArray(get("https://api.modrinth.com/v2/project/${enc(id)}/version?loaders=${enc(ld)}&game_versions=${enc("[\"${p.mc}\"]")}"))
            if (arr.length() == 0) return "No '$id' for ${p.loader} ${p.mc}"
            val files = arr.getJSONObject(0).getJSONArray("files")
            var f = files.getJSONObject(0)
            for (i in 0 until files.length()) if (files.getJSONObject(i).optBoolean("primary")) f = files.getJSONObject(i)
            val dest = File(dir, f.getString("filename").replace('/', '_'))
            if (dest.exists()) return "'$id' already present"
            val tmp = File(dir, dest.name + ".part")
            val c = URL(f.getString("url")).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "NOVA-Launcher/0.2 (android)")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            val want = f.optJSONObject("hashes")?.optString("sha1").orEmpty()
            if (want.isNotEmpty() && sha1(tmp) != want) { tmp.delete(); return "Checksum failed for '$id'" }
            tmp.renameTo(dest)
            "Added ${dest.name}"
        } catch (e: Exception) { "Could not add '$id' (${e.message})" }
    }
}
