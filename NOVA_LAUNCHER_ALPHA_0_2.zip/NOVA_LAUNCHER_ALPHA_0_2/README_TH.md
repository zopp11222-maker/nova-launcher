# NOVA LAUNCHER — Alpha 0.2

## ใหม่ใน 0.2
- นำเข้า .jar หลายไฟล์ ลงโฟลเดอร์ของแต่ละ Profile (บันทึกถาวร)
- อ่านข้อมูล mod จริง: Fabric / Quilt / Forge / NeoForge
- ตรวจ: dependency ที่ขาด, mod ซ้ำ, ผิด loader, mod ที่ประกาศว่าชนกัน
- Auto-fix: โหลด mod ที่ขาดจาก Modrinth (ตรวจ checksum) และ "ปิด" mod ที่ชน (เปลี่ยนชื่อเป็น .disabled ไม่ลบ) โดยถามก่อนเสมอ
- Profile มี loader + เวอร์ชัน Minecraft

## ข้อจำกัด
- ยังไม่เช็คช่วงเวอร์ชันของ dependency
- mod ที่ซ้อนอยู่ใน jar อื่น (jar-in-jar) อาจแจ้งว่าขาดผิดได้
- ยังรัน Minecraft ไม่ได้ (แผน Alpha 0.4)

## Build เป็น APK ผ่านมือถือ (ไม่ต้องใช้คอม)
1. สร้าง repo ใน GitHub แล้วอัปโหลดทุกไฟล์ในโฟลเดอร์นี้ (รวมโฟลเดอร์ .github)
2. แท็บ Actions → Build NOVA APK → รอให้เสร็จ
3. ดาวน์โหลด Artifact `NOVA-debug-apk` แล้วแตก zip จะได้ไฟล์ .apk
(หรือเปิดใน AndroidIDE แล้ว Build ตามเดิม)
